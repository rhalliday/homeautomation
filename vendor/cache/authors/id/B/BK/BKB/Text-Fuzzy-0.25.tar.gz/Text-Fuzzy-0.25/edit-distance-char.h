#line 2 "edit-distance.h.tmpl"
#ifndef EDIT_DISTANCE_CHAR_H
#define EDIT_DISTANCE_CHAR_H
#line 1 "declaration"
int distance_char (
                    text_fuzzy_t * tf)
;
#line 7 "edit-distance.h.tmpl"
#endif /* EDIT_DISTANCE_CHAR_H */
