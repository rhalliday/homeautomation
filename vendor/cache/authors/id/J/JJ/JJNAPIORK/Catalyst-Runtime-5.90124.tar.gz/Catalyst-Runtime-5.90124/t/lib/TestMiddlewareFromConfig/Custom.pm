package TestMiddlewareFromConfig::Custom;

use strict;
use warnings;

use parent qw/Plack::Middleware::Static/;

1;
