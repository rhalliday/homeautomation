# back compatibility package for any code explicitly checking
# that the filehandle object is a Fh
package Fh;

use strict;
use warnings;

$Fh::VERSION = '4.40';

1;
