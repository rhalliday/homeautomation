package Widget::Field::Omega;

use Moose::Role;

sub render
{
   return "<h1>You got here!</h1>";
}

1;
