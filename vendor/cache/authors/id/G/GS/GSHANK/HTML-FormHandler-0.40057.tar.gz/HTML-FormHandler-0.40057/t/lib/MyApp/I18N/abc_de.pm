package MyApp::I18N::abc_de;
use base 'HTML::FormHandler::I18N';

# Auto define lexicon
our %Lexicon = (
    '_AUTO' => 1,
    'You lost, insert coin' => 'Loser! coin needed',
    'Test field' => 'Asdf lkjh',
);

1;
