package TestClass;
use strict;
use warnings;

# This base class is just fine.

use Test::Class::Moose;

1;
