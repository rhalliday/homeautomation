package ClassA;

use Test::Class::Moose;

sub test_a {
    ok( 1, 'package A' );
}

1;
