package ClassB;

use Test::Class::Moose;

sub test_b {
    ok( 1, 'package B' );
}

1;
