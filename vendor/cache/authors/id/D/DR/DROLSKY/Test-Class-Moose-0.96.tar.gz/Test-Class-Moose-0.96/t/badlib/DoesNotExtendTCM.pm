package DoesNotExtendTCM;
use strict;
use warnings;

# This is not a Test::Class::Moose class and thus can not be used
# to extend a Test::Class::Moose class.

1;
