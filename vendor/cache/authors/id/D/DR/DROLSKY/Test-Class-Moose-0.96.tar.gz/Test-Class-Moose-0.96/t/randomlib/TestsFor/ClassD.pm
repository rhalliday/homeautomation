package ClassD;

use Test::Class::Moose;

sub test_d {
    ok( 1, 'package D' );
}

1;
