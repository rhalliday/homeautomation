package IncTestApp::Controller::Root;

use strict;
use warnings;
use File::Spec::Functions;

use base qw/Catalyst::Controller/;

__PACKAGE__->config(namespace => '');

1;
