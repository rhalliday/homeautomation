package ClobberDollarUnderscore;
use Moose;

$_ = undef;
1;

