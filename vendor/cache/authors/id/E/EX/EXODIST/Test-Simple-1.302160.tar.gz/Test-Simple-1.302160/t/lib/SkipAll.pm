package SkipAll;
use strict;
use warnings;

main::skip_all("foo");

1;
