package outer_diamond_E;

use outer_diamond_S;

1;
__END__